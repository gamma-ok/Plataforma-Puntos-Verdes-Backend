package pe.com.puntosverdes.dto;

public class CambioPasswordDTO {

	private String nuevaContrasena;

    public String getNuevaContrasena() {
        return nuevaContrasena;
    }

    public void setNuevaContrasena(String nuevaContrasena) {
        this.nuevaContrasena = nuevaContrasena;
    }
}
